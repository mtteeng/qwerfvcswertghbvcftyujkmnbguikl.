// let form = document.forms.registration;
// // console.log(form.elements.name.value)
// // console.log(form.elements.agree.checked)
// // console.log(form.elements.select.value)
// // let opt = foem.elements.select.options[2]
// // opt.selected = true
// let select = form.elements.select
// let option = new Option('Niznekamsk', '4')

// let input = document.querySelector('.input');
// let newElem;

// input.addEventListener('click', () => {
//     newElem = document.createElement('textarea')
//     newElem.innerHTML = input.textContent;

//     newElem.onblur = blurText;

//     input.replaceWith(newElem)
// })

// function blurText(){
//     input.textContent = newElem.value;
//     newElem.replaceWith(input)
// }

// let users = []
// async function getInfo(){
//     let data = await fetch('https://jsonplaceholder.typicode.com/users')
//     if (data.ok){
//         let info = await data.json()
//         console.log(info[0].address.city)
//         users = info;
//         let people = users.map(user => {
//             return document.querySelector('.wrap').insertAdjacentHTML('beforeend',<h1>${user.name}</h1>)
//         })

//     }else{
//         console.log(data.status)
//         return false
//     }
// }

let users = []
let newPost = {
    "userId":1,
    'title':'New post',
    "body":'New text'
}
function sendInfo(){
    fetch('https://jsonplaceholder.typicode.com/posts',
    {
        method: "POST",
        headers:{
            'Content-Type':'application/json'
        },
        body: JSON.stringify(newPost)
    }
    )
    .then(data => data.json())
    .then(data =>postPrint(data))
}

function postPrint(post){
    let elem = document.querySelector('.wrap')
    elem.insertAdjacentHTML('beforeend',
            `<h1>${post.title} </h1>
            <p> ${post.body} </p>`
        )
    
}